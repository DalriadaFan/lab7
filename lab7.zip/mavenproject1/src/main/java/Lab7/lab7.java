package Lab7;
import au.com.bytecode.opencsv.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;



public class lab7 {
    
    public static void main(String[] args){
        CSV nice = new CSV();
        nice.cool();
    }
}
