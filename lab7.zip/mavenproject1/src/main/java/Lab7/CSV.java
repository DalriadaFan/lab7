package Lab7;
import au.com.bytecode.opencsv.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;




public class CSV {

    CSVReader reader;
    String[] nextLine;
    int lines=1;

    public void cool() {
        try {
            this.reader = new CSVReader(new FileReader("test_two-anon.csv"));
            try {
                while ((nextLine = reader.readNext()) != null) {
                    // nextLine[] is an array of values from the line
                    System.out.println(nextLine[0] + nextLine[1] + "etc...");
                    if(lines==1)
                        break;
                }
            } catch (IOException ex) {
                Logger.getLogger(lab7.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(lab7.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    String getLines(){
        return nextLine[0];
    }

}
