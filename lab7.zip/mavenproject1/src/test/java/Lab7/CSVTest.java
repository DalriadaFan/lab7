/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab7;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author shasany.bscs14seecs
 */
public class CSVTest {
    
    public CSVTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of cool method, of class CSV.
     */
    @org.junit.Test
    public void testCool() {
        System.out.println("cool");
        CSV instance = new CSV();
        instance.cool();
        assertEquals(instance.getLines(),"USERID");
        fail("The test case is a prototype.");
    }
    
}
